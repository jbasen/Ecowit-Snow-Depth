﻿using System.Reflection;

[assembly: AssemblyTitle("Ecowitt_LDS01_Snow_Depth_Sensor")]
[assembly: AssemblyCompany("HP Inc.")]
[assembly: AssemblyProduct("Ecowitt_LDS01_Snow_Depth_Sensor")]
[assembly: AssemblyCopyright("Copyright © HP Inc. 2025")]
[assembly: AssemblyVersion("1.0.0.*")]

