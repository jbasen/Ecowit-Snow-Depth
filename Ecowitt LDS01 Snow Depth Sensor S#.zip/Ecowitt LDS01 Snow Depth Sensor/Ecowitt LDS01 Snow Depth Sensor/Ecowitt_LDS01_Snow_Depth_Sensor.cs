﻿using System;
using System.Text;
using Crestron.SimplSharp;                          				// For Basic SIMPL# Classes
using Crestron.SimplSharp.Net.Https;
using Crestron.SimplSharp.WebScripting;
using Newtonsoft.Json;
using System.Collections.Generic;
using Crestron.SimplSharp.CrestronIO;

namespace Ecowitt_LDS01_Snow_Depth_Sensor_Integration
{
	#region Delegates
	public delegate void DelegateFn1(ushort Depth1, ushort Depth2, ushort Depth3, ushort Depth4, SimplSharpString Depth_Unit, ushort Battery1, ushort Battery2, ushort Battery3, ushort Battery4, SimplSharpString Battery_Unit);
	public delegate void DelegateFn2(ushort Snow_Storm_Depth);
	public delegate void DelegateFn3();
	#endregion

	#region Enum
	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};
	enum Forecast_Options
	{
		Snow,
		No_Snow,
		Unknown
	};
	enum Status_Options
	{
		Waiting_for_Prediction_of_Snow,
		Waiting_for_Snow_to_Start,
		Actively_Snowing
	};
	enum Pressure_Trend_Options
	{
		rising,
		falling,
		steady,
		Unknown
	};
	#endregion

	public class Ecowitt_LDS01_Snow_Depth_Sensor
	{
		#region Callbacks
		public static DelegateFn1 callback_fn1 { get; set; }
		public DelegateFn2 callback_fn2 { get; set; } //Pass Back Snow Storm Snow Accumulation
		public DelegateFn3 callback_fn3 { get; set; } //Pass Back to Send Notification to Clear Driveway
		#endregion

		#region Declarations
		private static HttpCwsServer server;
		private static Debug_Options Debug;
		private static double[] Sensor_Height = new double[4];  //hundreds of an inch or mm
		private static short Measurement_System; //0 = imperial, 1 = metric
		private double Notification_Height;//inches or cm
		private Forecast_Options Forecast = Forecast_Options.Unknown;
		private Pressure_Trend_Options Pressure_Trend = Pressure_Trend_Options.Unknown;
		private Status_Options Status = Status_Options.Waiting_for_Prediction_of_Snow;
		private MyQueue q = new MyQueue();
		private double Pre_Storm_Snow_Depth;
		private double Driveway_Cleared_Snow_Depth;
		private double Snow_Storm_Total;
		private const int Max_Sensor_Count = 4;
		private CTimer cTimer = null;
		private const long No_Data_Timer_MSEC = 86400000;
		#endregion

		//****************************************************************************************
		// 
		//  Ecowitt_LDS01_Snow_Depth_Sensor	-	Constructor
		// 
		//****************************************************************************************
		public Ecowitt_LDS01_Snow_Depth_Sensor()
		{
		}

		//****************************************************************************************
		// 
		//  Ecowitt_Initialization	-	
		// 
		//****************************************************************************************
		public static void Ecowitt_Initialization(short Measurement_System_Param, short Sensor_Height1_Param, short Sensor_Height2_Param, short Sensor_Height3_Param, short Sensor_Height4_Param, short Debug_Param)
		{
			Set_Debug_Message_Output(Debug_Param);

			Debug_Message("Ecowitt_Initialization", "Start");

			#region Save Parameters to globals
			Measurement_System = Measurement_System_Param;
			Sensor_Height[0] = Convert.ToDouble(Sensor_Height1_Param);
			Sensor_Height[1] = Convert.ToDouble(Sensor_Height2_Param);
			Sensor_Height[2] = Convert.ToDouble(Sensor_Height3_Param);
			Sensor_Height[3] = Convert.ToDouble(Sensor_Height4_Param);
			Debug_Message("Ecowitt_Initialization", "Parameters Saved");
			#endregion

			#region Start Server
			try
			{
				server = new HttpCwsServer("/snow_data"); // The virtual path provided here represents the beginning of the path after "/cws"
				server.HttpRequestHandler = new DefaultHandler();
				server.Register();
				Debug_Message("Ecowitt_Initialization", "Server Started");
			}
			catch (Exception e)
			{
				CrestronConsole.PrintLine(string.Format("Ecowitt LDS01 Snow Depth Sensor - Can't create CWS server: " + e));
				Crestron.SimplSharp.ErrorLog.Error(string.Format("Ecowitt LDS01 Snow Depth Sensor - Can't create CWS server: " + e + "\n"));
			}
			#endregion

			Debug_Message("Ecowitt_Initialization", "End");
		}

		//****************************************************************************************
		// 
		//  Snow_Depth_Initialization	-	
		// 
		//****************************************************************************************
		public void Snow_Depth_Initialization(short Notification_Height)
		{
			Debug_Message("Snow_Depth_Initialization", "Start");

			#region Save Parameters to globals
			this.Notification_Height = Convert.ToDouble(Notification_Height);
			#endregion

			#region Start Timer
			Start_No_Data_Timer();		
			#endregion

			Debug_Message("Snow_Depth_Initialization", "End");
		}
		//****************************************************************************************
		// 
		// Start_No_Data_Timer	-	Main timer for no data for a full day - Restart Queue
		// 
		//****************************************************************************************
		private void Start_No_Data_Timer()
		{
			if ((cTimer == null) || (cTimer.Disposed))
			{
				try
				{
					CTimerCallbackFunction cTimerCallbackFunction = new CTimerCallbackFunction(No_Data_Timer_Thread);
					cTimer = new CTimer(No_Data_Timer_Thread, null, No_Data_Timer_MSEC);
					Debug_Message("Start_No_Data_Timer", "No Data Timer Created");

				}
				catch (Exception e)
				{
					Debug_Message("Start_No_Data_Timer", "Can't create timer thread: " + e + "\n");
					Debug_Message("Start_No_Data_Timer", "Can't create timer thread: " + e + "\n");
				}
			}
			else
			{
				try
				{
					//restart timer
					Debug_Message("Start_No_Data_Timer", "Restarting Timer\n");
					cTimer.Stop();
					cTimer.Reset(No_Data_Timer_MSEC);
					Debug_Message("Start_No_Data_Timer", "No Data Timer Restarted");
				}
				catch (Exception e)
				{
					Debug_Message("Start_No_Data_Timer", "Can't restart timer thread: " + e + "\n");
					Crestron.SimplSharp.ErrorLog.Error("Snow_Depth_Initialization - Can't restart timer thread: " + e + "\n");
				}
			}
		}

		//****************************************************************************************
		// 
		//  No_Data_Timer_Thread	-	Main timer for no data for a full day - Restart Queue
		// 
		//****************************************************************************************
		private void No_Data_Timer_Thread(Object unused)
		{
			Debug_Message("No_Data_Timer_Thread", "Timer Expired");

			q.Clear();	//Clear all data in queue.  Force system to start over capturing data
		}

		//****************************************************************************************
		// 
		//  Set_Forecast	-	Is snow in the forecast
		// 
		//****************************************************************************************
		public void Set_Forecast(string Forecast_String)
		{
			Debug_Message("Set_Forecast", "Forecast_String = " + Forecast_String);

			Forecast_String = Forecast_String.ToLower();
			if (string.IsNullOrEmpty(Forecast_String) == true)
			{
				Forecast = Forecast_Options.Unknown;
			}
			else if (Forecast_String.Contains("snow") || Forecast_String.Contains("mix") || Forecast_String.Contains("wintry"))
			{
				Forecast = Forecast_Options.Snow;
			}
			else
			{
				Forecast = Forecast_Options.No_Snow;
			}
		}

		//****************************************************************************************
		// 
		//  Set_Pressure_Trend	-	Is pressure rising, falling, or steady
		// 
		//****************************************************************************************
		public void Set_Pressure_Trend(string Pressure_Trend_String)
		{
			Debug_Message("Set_Pressure_Trend", "Pressure_Trend_String = " + Pressure_Trend_String);

			Pressure_Trend_String = Pressure_Trend_String.ToLower();
			if (string.IsNullOrEmpty(Pressure_Trend_String) == true)
			{
				Pressure_Trend = Pressure_Trend_Options.Unknown;
			}
			else if (Pressure_Trend_String.Contains("rising"))
			{
				Pressure_Trend = Pressure_Trend_Options.rising;
			}
			else if (Pressure_Trend_String.Contains("falling"))
			{
				Pressure_Trend = Pressure_Trend_Options.falling;
			}
			else if (Pressure_Trend_String.Contains("steady"))
			{
				Pressure_Trend = Pressure_Trend_Options.steady;
			}
			else
			{
				Pressure_Trend = Pressure_Trend_Options.Unknown;
			}
		}

		//****************************************************************************************
		// 
		//  CWS_Message_Handler	-	
		// 
		//****************************************************************************************
		public static void CWS_Message_Handler(string s)
		{
			string t;
			double Measured_Height;
			double[] Depth = new double[Max_Sensor_Count];
			string Depth_Unit;
			double[] Battery = new double[Max_Sensor_Count];

			Debug_Message("CWS_Message_Handler", "s = " + s);

			#region Set Depth Units
			if (Measurement_System == 0)
			{
				//Imperial
				Depth_Unit = "in*100";
			}
			else
			{
				//Metric
				Depth_Unit = "mm";
			}
			#endregion

			try
			{
				for (int i = 0; i < Max_Sensor_Count; i++)	//loop through sensors
				{
					#region Calculate Depth
					t = Parse_Data_Substring(s, "air_ch" + (i + 1) + "=", "&");
					if (string.IsNullOrEmpty(t) == true)
					{
						Debug_Message("CWS_Message_Handler", "No Data for Sensor - " + i);
						Depth[i] = 0;

					}
					else
					{
						Measured_Height = double.Parse(t);
						Debug_Message("CWS_Message_Handler", "Measured_Height = " + Measured_Height);
						if (Measurement_System == 0)
						{
							//Imperial
							Depth[i] = Sensor_Height[i] - (Measured_Height / .254);
						}
						else
						{
							//Metric
							Depth[i] = Sensor_Height[i] - Measured_Height;
						}

						//Prep for sending back to SimplWin
						Depth[i] = Math.Round(Depth[i], 0);
						if (Depth[i] < 0)
						{
							Depth[i] = 0;
						}
						Debug_Message("CWS_Message_Handler", "Depth = " + Depth[i] + " " + Depth_Unit);
					}
					#endregion

					#region Battery Level
					t = Parse_Data_Substring(s, "ldsbatt" + (i + 1) + "=", "&");
					if (string.IsNullOrEmpty(t) == true)
					{
						Debug_Message("CWS_Message_Handler", "No Data for Sensor Battery - " + i);
						Battery[i] = 0;
					}
					else
					{
						Battery[i] = double.Parse(t);
						Battery[i] = Battery[i] * 100;
						Debug_Message("CWS_Message_Handler", "Battery = " + Battery[i] + " " + "V*100");
					}
					#endregion
				}

				callback_fn1(Convert.ToUInt16(Depth[0]), Convert.ToUInt16(Depth[1]), Convert.ToUInt16(Depth[2]), Convert.ToUInt16(Depth[3]), Depth_Unit, 
					Convert.ToUInt16(Battery[0]), Convert.ToUInt16(Battery[1]), Convert.ToUInt16(Battery[2]), Convert.ToUInt16(Battery[3]), "V*100");
			}
			catch (Exception e)
			{
				CrestronConsole.PrintLine(string.Format("CWS_Message_Handler - Error = " + e));
				Crestron.SimplSharp.ErrorLog.Error(string.Format("CWS_Message_Handler - Error = " + e + "\n"));
			}
		}

		//****************************************************************************************
		// 
		//  Snow_Depth	-	
		// 
		//****************************************************************************************
		public void Snow_Depth(short value)
		{
			double Depth;

			#region Restart No Data Timer
			Start_No_Data_Timer();
			#endregion

			#region Convert to Proper Units
			if (Measurement_System == 0)
			{
				//Imperial
				Depth = Convert.ToDouble(value);
				Depth = Depth / 100;	//inches
				Debug_Message("Snow_Depth", "Depth = " + Depth + " inches");
			}
			else
			{
				//Metric
				Depth = Convert.ToDouble(value);
				Depth = Depth / 10;		//cm
				Debug_Message("Snow_Depth", "Depth = " + Depth + " cm");
			}
			#endregion

			#region Snow Blowing Notifications
			#region Collect Snow Data
			q.Enqueue(Depth);										//store latest reading
			if (q.Count() < MyQueue.size)							//check if enough data collected (15 minutes)
			{
				Debug_Message("Snow_Depth", "Not Enough Data - Queue Count = " + q.Count());
				return;												//System just started, not enough data
			}
			#endregion

			#region Snow Predicted
			if ((Forecast == Forecast_Options.Snow) && (Status == Status_Options.Waiting_for_Prediction_of_Snow))
			{
				Debug_Message("Snow_Depth", "Snow Predicted - Depth = " + Depth);
				Pre_Storm_Snow_Depth = Depth;						//store for storm total calculation
				Driveway_Cleared_Snow_Depth = Depth;				//store for snow blow reminder
				Status = Status_Options.Waiting_for_Snow_to_Start;
			}
			#endregion

			#region Started Snowing
			if (((Depth - Pre_Storm_Snow_Depth) >= .5) && (Status == Status_Options.Waiting_for_Snow_to_Start))
			{
				Debug_Message("Snow_Depth", "Started Snowing - Depth = " + Depth);
				Status = Status_Options.Actively_Snowing;
			}
			#endregion

			#region Save Current Storm Total
			if (Status == Status_Options.Actively_Snowing)
			{
				Snow_Storm_Total = Depth - Pre_Storm_Snow_Depth;
				Debug_Message("Snow_Depth", "Save Current Storm Total - Depth = " + Depth + ", Snow_Storm_Total = " + Snow_Storm_Total);
				callback_fn2(Convert.ToUInt16(Math.Round(Snow_Storm_Total, 0)));//pass back snow storm total accumulation
			}
			#endregion

			#region Clear Driveway Warning
			if ((Depth - Driveway_Cleared_Snow_Depth) >= Notification_Height)
			{
				Debug_Message("Snow_Depth", "Save Clear Driveway Warning - Depth = " + Depth + ", Snow_Storm_Total = " + Snow_Storm_Total);
				callback_fn3();	//Tell SimplWindows layer to send notification to clear driveway
				Driveway_Cleared_Snow_Depth = Depth;
			}
			#endregion

			#region Storm Ending
			if (((Depth - q.Peek()) < .1) && (Status == Status_Options.Actively_Snowing) 
				&& ((Pressure_Trend == Pressure_Trend_Options.rising) || (Forecast == Forecast_Options.No_Snow)))
			{
				Snow_Storm_Total = Depth - Pre_Storm_Snow_Depth;
				Debug_Message("Snow_Depth", "Storm Ending - Depth = " + Depth + ", Storm Total = " + Snow_Storm_Total);
				callback_fn2(Convert.ToUInt16(Math.Round(Snow_Storm_Total, 0)));//pass back snow storm total accumulation
				Status = Status_Options.Waiting_for_Prediction_of_Snow;
			}
			#endregion

			#region Forecast Wrong, Never Snowed
			if ((Status == Status_Options.Waiting_for_Snow_to_Start) && (Forecast == Forecast_Options.No_Snow))
			{
				Debug_Message("Snow_Depth", "Forecast Wrong, Never Snowed");
				Status = Status_Options.Waiting_for_Prediction_of_Snow;
			}
			#endregion
			#endregion
		}

		//****************************************************************************************
		// 
		//  Parse_Data_Substring	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		private static string Parse_Data_Substring(string s, string id, string ending_char)
		{
			int index1, index2;
			string t;

			//get index to start of value
			index1 = s.IndexOf(id, 0);
			if (index1 == -1)
			{
				return "";
			}
			else
			{
				index1 += id.Length;
			}

			//get index to end of value
			index2 = s.IndexOf(ending_char, (index1 + 1));
			if (index2 == -1)
			{
				CrestronConsole.PrintLine("Ecowitt LDS01 Snow Depth Sensor - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				Crestron.SimplSharp.ErrorLog.Error("Ecowitt LDS01 Snow Depth Sensor - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				return "";
			}

			//get value substring and pass it back
			t = s.Substring(index1, index2 - index1);
			Debug_Message("Parse_Data_Substring", id + " = " + t);
			return t;
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		private static void Set_Debug_Message_Output(short Debug_Param)
		{
			//Save debug message setting as an enum
			switch (Debug_Param)
			{
				case 0:
					Debug = Debug_Options.None;
					break;

				case 1:
					Debug = Debug_Options.Console;
					break;

				case 2:
					Debug = Debug_Options.Error_Log;
					break;

				case 3:
					Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private static void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 250;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("Ecowitt LDS01 Snow Depth Sensor - " + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("Ecowitt LDS01 Snow Depth Sensor - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}
	}

	#region Queue Classes
	public class MyQueue 
	{
		#region Declarations
		private Queue<double> q;
		public const int size = 15;
		#endregion

		//****************************************************************************************
		// 
		//  Constructor	-	
		// 
		//****************************************************************************************
		public MyQueue()
		{
			q = new Queue<double>();
		}

		//****************************************************************************************
		// 
		//  Enqueue	-	Add Item to the Queue.  If the queue is full
		//				remove an item to make room
		// 
		//****************************************************************************************
		public void Enqueue(double d)
		{
			if (q.Count == size)
			{
				q.Dequeue();
			}
			q.Enqueue(d);
		}

		//****************************************************************************************
		// 
		//  Dequeue	-	Remove Item from the Queue
		// 
		//****************************************************************************************
		public double Dequeue()
		{
			return q.Dequeue();
		}

		//****************************************************************************************
		// 
		//  Peek	-	Peek at oldest item in the queue
		// 
		//****************************************************************************************
		public double Peek()
		{
			return q.Peek();
		}

		//****************************************************************************************
		// 
		//  Count	-	Returns the number of elements in the queue
		// 
		//****************************************************************************************
		public int Count()
		{
			return q.Count;
		}

		//****************************************************************************************
		// 
		//  Clear	-	Clear all elements in the queue
		// 
		//****************************************************************************************
		public void Clear()
		{
			q.Clear();
		}
	}
	#endregion

	#region Web Scripting Class
	class DefaultHandler : IHttpCwsHandler
	{
		string allowedMethods = "GET, POST"; // value of the "Allow" header when the server returns a "Method Not Allowed" response

		public void ProcessRequest(HttpCwsContext context)
		{
			if ((context.Request.HttpMethod == "GET") || (context.Request.HttpMethod == "POST"))
			{
				StreamReader reader = new StreamReader(context.Request.InputStream);
				string text = reader.ReadToEnd();
				Ecowitt_LDS01_Snow_Depth_Sensor.CWS_Message_Handler(text);

				context.Response.StatusCode = 200;
				context.Response.StatusDescription = "OK";
				context.Response.End();
			}
			else
			{
				context.Response.StatusCode = 405;
				context.Response.StatusDescription = "Method Not Allowed";
				context.Response.AppendHeader("Allow", allowedMethods);
				context.Response.End();

				CrestronConsole.PrintLine("CWS_Test-Error = Illegal Content Type");
			}
		}
	};
	#endregion

}
